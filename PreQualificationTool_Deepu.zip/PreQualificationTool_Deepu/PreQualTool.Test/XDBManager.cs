﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PreQualTool.Data;
using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace PreQualTool.Test
{
    public class XDBManager
    {

        public ServiceProvider _ServiceProvider { get; private set; }
        public XDBManager()
        {           
            var services = new ServiceCollection();           
            var config = new ConfigurationBuilder()
               .AddJsonFile("Config.json")
               .Build();
            var connectionString = config.GetConnectionString("PreQualDBConnection");

            services
            .AddDbContext<PreQualDBContext>(options => options.UseSqlServer(connectionString),
                ServiceLifetime.Transient);
            _ServiceProvider = services.BuildServiceProvider();
        }
        
    }    
}
