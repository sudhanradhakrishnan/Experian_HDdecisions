using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;
using PreQualTool.Data;
using PreQualTool.Services;
using PreQualTool.ViewModel;
using System;
using Xunit;

namespace PreQualTool.Test
{
    public class PreQualTest : IClassFixture<XDBManager>
    {
        private ServiceProvider _serviceProvide;

        public  PreQualTest(XDBManager _mgr)
        {

            _serviceProvide = _mgr._ServiceProvider;

        }

        /// <summary>
        /// Test Method For checking Income grater than 30000 condition
        /// </summary>
        [Fact]
        public void SubmitData_Barclaycard()
        {
            using (var context = _serviceProvide.GetService<PreQualDBContext>())
            {                        
                var mockRepoLogger = new Mock<ILogger<PreQualRepository>>().Object;
                var mockCustomerServiceLogger = new Mock<ILogger<PreQualService>>().Object;
                IPreQualRepository _PreQualRepository = new PreQualRepository(context, mockRepoLogger);
                var _Service = new PreQualService(_PreQualRepository, mockCustomerServiceLogger);
                CustomerDetailsVM _mockData = new CustomerDetailsVM();
                _mockData.FirstName = "Albert";
                _mockData.LastName = "James";
                _mockData.IsEligible = true;
                _mockData.DateOfBirth = new DateTime(1981, 08, 02);
                _mockData.AnnualIncome = 35000;        
                CustomerCardDetailsVM saveResult = _Service.SubmitData(_mockData);                
                Assert.NotNull(saveResult);
                Assert.Equal("Barclaycard Credit Card", saveResult.CardName);
            }
        }

        /// <summary>
        /// Test Method For checking Income less than 30000 condition
        /// </summary>
        [Fact]
        public void SubmitData_VanquisCard()
        {
            using (var context = _serviceProvide.GetService<PreQualDBContext>())
            {                       
                var mockRepoLogger = new Mock<ILogger<PreQualRepository>>().Object;
                var mockCustomerServiceLogger = new Mock<ILogger<PreQualService>>().Object;
                IPreQualRepository _PreQualRepository = new PreQualRepository(context, mockRepoLogger);
                var _Service = new PreQualService(_PreQualRepository, mockCustomerServiceLogger);
                CustomerDetailsVM _mockData = new CustomerDetailsVM();
                _mockData.FirstName = "Albert";
                _mockData.LastName = "James";
                _mockData.IsEligible = true;
                _mockData.DateOfBirth = new DateTime(1981, 08, 02);
                _mockData.AnnualIncome = 20000;                
                CustomerCardDetailsVM saveResult = _Service.SubmitData(_mockData);             
                Assert.NotNull(saveResult);
                Assert.Equal("Vanquis Credit Card", saveResult.CardName);
            }
        }

        /// <summary>
        /// Test Method For checking age less than 18 condition
        /// </summary>
        [Fact]
        public void SubmitData_AgeValidation()
        {
            using (var context = _serviceProvide.GetService<PreQualDBContext>())
            {           
                var mockRepoLogger = new Mock<ILogger<PreQualRepository>>().Object;
                var mockCustomerServiceLogger = new Mock<ILogger<PreQualService>>().Object;
                IPreQualRepository _PreQualRepository = new PreQualRepository(context, mockRepoLogger);
                var _Service = new PreQualService(_PreQualRepository, mockCustomerServiceLogger);
                CustomerDetailsVM _mockData = new CustomerDetailsVM();
                _mockData.FirstName = "Albert";
                _mockData.LastName = "James";
                _mockData.IsEligible = true;
                _mockData.DateOfBirth = new DateTime(2015, 08, 02);
                _mockData.AnnualIncome = 40000;                
                CustomerCardDetailsVM saveResult = _Service.SubmitData(_mockData);                
                Assert.NotNull(saveResult);
                Assert.Equal("You are not eligible for Credit Card at this time", saveResult.PromoMessage);

            }
        }
    }
}
