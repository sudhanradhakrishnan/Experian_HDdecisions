﻿using PreQualTool.Models;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace PreQualTool.Data
{
    public class DataSeed
    {
        private readonly PreQualDBContext _ctx;
        private readonly IWebHostEnvironment _hosting;

        #region  Constructor
       
        public DataSeed(PreQualDBContext ctx, IWebHostEnvironment hosting)
        {
            _ctx = ctx;
            _hosting = hosting;
        }

        #endregion

        #region Methods

        /// <summary>
        /// For inistial data setup fetching fetching data from json file  
        /// </summary>
        public void Seed()
        {
            _ctx.Database.EnsureCreated();

            if (!_ctx.CardDetails.Any())
            {
                // Need to create sample data
                var filepath = Path.Combine(_hosting.ContentRootPath, "DataServices/dataforCardDetails.json");
                var json = File.ReadAllText(filepath);
                var ccType = JsonConvert.DeserializeObject<IEnumerable<CardDetails>>(json);
                _ctx.CardDetails.AddRange(ccType);

                var type = _ctx.CardDetails.Local.Any(y => y.Id == 0);
                if (type)
                {
                    _ctx.CardDetails.AddRange(ccType);
                    _ctx.SaveChanges();
                }               

            }
        }

        #endregion
    }
}
