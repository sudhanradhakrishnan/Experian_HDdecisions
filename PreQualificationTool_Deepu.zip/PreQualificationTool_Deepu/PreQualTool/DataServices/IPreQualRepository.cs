﻿using PreQualTool.Models;
using System.Collections.Generic;


namespace PreQualTool.Data
{
    public interface IPreQualRepository
    {
        IEnumerable<CustomerInfo> GetCustomerDetails();
        IEnumerable<CardDetails> GetCardDetails(decimal custIncome);

        void AddCustomer(CustomerInfo customer);
        void AddCustomerCardDetails(CustomerCardDetails custCarddetail);
        bool SaveAll();

     
    }
}
