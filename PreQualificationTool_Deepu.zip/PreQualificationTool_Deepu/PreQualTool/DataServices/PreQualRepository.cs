﻿using PreQualTool.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PreQualTool.Data
{
    public class PreQualRepository : IPreQualRepository
    {
       
        private readonly PreQualDBContext _ctx;
        private readonly ILogger<PreQualRepository> _logger;

        #region constructor
      
        public PreQualRepository(PreQualDBContext ctx, ILogger<PreQualRepository> logger)
        {
            _ctx = ctx;
            _logger = logger;
        }

        #endregion

        #region Methods
       
        /// <summary>
        /// Method for adding customer data to databse
        /// </summary>
        /// <param name="customer"></param>
        public void AddCustomer(CustomerInfo customer)
        {
            try
            {
                _ctx.CustomerInfo.Add(customer);
            }
            catch (Exception ex)
            {

                _logger.LogError($"Add customer failed: {ex}");
            }
           
        }

        /// <summary>
        /// For adding customer and card details to database
        /// </summary>
        /// <param name="custCarddetail"></param>
        public void AddCustomerCardDetails(CustomerCardDetails custCarddetail)
        {
            try
            {
                _ctx.CustomerCardDetails.Add(custCarddetail);
            }
            catch (Exception ex)
            {

                _logger.LogError($"Customer and Card details saving failed: {ex}");
                
            }
           
        }

        /// <summary>
        /// This method will return customer details
        /// </summary>
        /// <returns></returns>
        public IEnumerable<CustomerInfo> GetCustomerDetails()
        {
            try
            {
                _logger.LogInformation("GetCustomerDetails was called");

                return _ctx.CustomerInfo
                           .OrderBy(p => p.FirstName)
                           .ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to get the Customer details: {ex}");
                return null;
            }
        }

        /// <summary>
        /// Method will return Card details based on customer 
        /// </summary>
        /// <param name="custIncome"></param>
        /// <returns></returns>
        public IEnumerable<CardDetails> GetCardDetails(decimal custIncome)
        {
            try
            {
                _logger.LogInformation("GetCardDetails was called");

                return _ctx.CardDetails
                    .Where(p => p.Incomethreshold <= custIncome)
                           .OrderBy(p => p.CardName)
                           .ToList();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to get the Card details: {ex}");
                return null;
            }
        }

        /// <summary>
        /// Method for Saving data to database
        /// </summary>
        /// <returns></returns>
        public bool SaveAll()
        {
            try
            {
                return _ctx.SaveChanges() > 0;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to save data: {ex}");
                return false;
            }
            
        }
        #endregion
    }
}
