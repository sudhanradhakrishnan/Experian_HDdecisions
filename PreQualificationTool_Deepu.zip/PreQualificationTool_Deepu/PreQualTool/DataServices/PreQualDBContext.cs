﻿using PreQualTool.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PreQualTool.Data  
{
    public class PreQualDBContext : DbContext
    {
        public PreQualDBContext(DbContextOptions<PreQualDBContext> options) : base(options)
        {

        }
        public DbSet<CustomerInfo> CustomerInfo { get; set; }

        public DbSet<CardDetails> CardDetails{ get; set; }

        public DbSet<CustomerCardDetails> CustomerCardDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<CustomerInfo>()
              .Property(p => p.AnnualIncome)
              .HasColumnType("decimal(18,2)");

            builder.Entity<CardDetails>()
              .Property(p => p.AnnualPercentageRate)
              .HasColumnType("decimal(18,2)");
        }
    }
}
