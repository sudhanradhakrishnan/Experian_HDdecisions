﻿					EXECUTION  INFO
			***********************************
Connection String :  \PreQualTool\Config.json
Master data Loading From :  \PreQualTool\DataServices\dataforCardDetails.json File
DB Name : PREQUAL
Approach : Entity Framework Code First Appraoch
Migration Script Generated and available in  \PreQualTool\Migrations\
Project  Path :- \PreQualTool\PreQualTool.sln

***************************************************************************

For Database Setup
1. From Package manager Console , Run -- >  Update-Database
