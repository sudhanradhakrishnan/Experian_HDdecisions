﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PreQualTool.ViewModel
{
    public class CustomerCardDetailsVM
    {
        public long Id { get; set; }
        public string CustomerFirstname { get; set; }
        public string CustomerLastName { get; set; }
        public string CardName { get; set; }        
        public decimal AnnualPercentageRate { get; set; }
        public string PromoMessage { get; set; }
        public bool IsEligible { get; set; }
    }
}
