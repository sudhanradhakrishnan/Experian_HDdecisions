﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PreQualTool.ViewModel
{
    public class CustomerInfoVM
    {
        public long Id { get; set; }
        public int FirstName { get; set; }
        public int LastName { get; set; }
        public DateTime DoB { get; set; }
        public decimal AnnualIncome { get; set; }
        public bool IsEligible { get; set; }
    }
}
