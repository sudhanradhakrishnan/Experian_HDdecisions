﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PreQualTool.ViewModel
{
    public class CustomerDetailsVM
    {
        public long Id { get; set; }

        [Required]
        [DisplayName("First Name")]
        [MaxLength(25)]
        public string FirstName { get; set; }

        [Required]
        [DisplayName("Last Name")]
        [MaxLength(25)]
        public string LastName { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        [DisplayName("DOB")]
        public DateTime DateOfBirth { get; set; }

        [Required]
        [Range(0, 9999999.99, ErrorMessage = "Invalid Annual Income; Max 8 digits")]
        [DisplayName("Annual Income")]
        public decimal AnnualIncome { get; set; }

        public bool IsEligible { get; set; }
    }
}
