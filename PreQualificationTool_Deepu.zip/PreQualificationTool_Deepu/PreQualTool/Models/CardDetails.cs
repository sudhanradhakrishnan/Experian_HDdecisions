﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PreQualTool.Models
{
    public class CardDetails : ModelBase
    {
        public string CardName { get; set; }
        public long Incomethreshold { get; set; }
        public decimal AnnualPercentageRate { get; set; }
        public string PromoMessage { get; set; }

    }
}
