﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace PreQualTool.Models
{
    public class CustomerCardDetails : ModelBase
    {
        [ForeignKey("CustomerInfo")] 
        public long CustomerId { get; set; }
        public CustomerInfo CustomerInfo { get; set; }

        [ForeignKey("CardDetails")]
        public long CardDetailsId { get; set; }
        public CardDetails CardDetails { get; set; }

    }
}
