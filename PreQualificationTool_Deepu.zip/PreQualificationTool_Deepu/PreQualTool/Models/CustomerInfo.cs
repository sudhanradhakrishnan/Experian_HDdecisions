﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PreQualTool.Models
{
    public class CustomerInfo : ModelBase
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DOB { get; set; }
        public decimal AnnualIncome { get; set; }
        public bool IsEligible { get; set; }
    
    }
}
