﻿using Microsoft.Extensions.Logging;
using PreQualTool.Data;
using PreQualTool.Models;
using PreQualTool.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PreQualTool.Services
{
    public class PreQualService : IPreQualService
    {
        private readonly IPreQualRepository _toolRepository;
        ICompositeValidator _validator = new CompositeValidator();
        private readonly ILogger<PreQualService> _logger;
        #region "Constrct"

        public PreQualService(IPreQualRepository PreQualRepository, ILogger<PreQualService> logger)
        {
            _toolRepository = PreQualRepository;
            _logger = logger; 

        }
        #endregion

        #region "Public Methods"
        /// <summary>
        /// Method For submiting Form data. Afiter basic validation primary data will save in database will give to
        /// second level business validation. After business validation end result will return.
        /// </summary>
        /// <param name="CustInfo"></param>
        /// <returns></returns>
        public CustomerCardDetailsVM SubmitData(CustomerDetailsVM custInfo)
        {           
            CustomerCardDetailsVM _customerardDetails = new CustomerCardDetailsVM();
            try
            {  
                if (_validator.Validate(custInfo))
                {
                    custInfo.IsEligible = true;
                    CustomerDetailsVM cInfo =  SaveCustData(custInfo);
                    if (cInfo.Id > 0)
                    {
                        _customerardDetails =  GetCardDetails(cInfo);
                        return _customerardDetails;
                    }                    
                }
                else
                {
                    custInfo.IsEligible = false;
                    _customerardDetails.CustomerFirstname = custInfo.FirstName;
                    _customerardDetails.CustomerLastName = custInfo.LastName;
                    _customerardDetails.IsEligible = false;
                    _customerardDetails.PromoMessage = "You are not eligible for Credit Card at this time";
                    return _customerardDetails;
                }
                ;

                return _customerardDetails;

            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to submit the data: {ex}");
                throw ex;
            }
            
        }

        #endregion

        #region "Private Methods"
        /// <summary>
        /// To save Customer data to Database, User entered inforation will save to database
        /// </summary>
        /// <param name="custInfo"></param>
        /// <returns></returns>
        private CustomerDetailsVM SaveCustData(CustomerDetailsVM custInfo)
        {
            try
            {
                if (custInfo != null)
                {
                    CustomerInfo customer = new CustomerInfo
                    {
                        FirstName = custInfo.FirstName,
                        LastName = custInfo.LastName,
                        DOB = custInfo.DateOfBirth,
                        AnnualIncome = custInfo.AnnualIncome,
                        CreatedDate = DateTime.Now.Date,
                        IsEligible = custInfo.IsEligible

                    };

                    _toolRepository.AddCustomer(customer);

                    _toolRepository.SaveAll();
                    custInfo.Id = customer.Id;

                }
                return custInfo;

            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to save customer data: {ex}");
                throw;
            }
            
        }
        
        /// <summary>
        /// To Fetch Card details from Database. Based on criteria this method will return card details.
        /// </summary>
        /// <param name="custInfo"></param>
        /// <returns></returns>
        private CustomerCardDetailsVM  GetCardDetails(CustomerDetailsVM custInfo)
        {
            try
            {
                var _cardDetails = _toolRepository.GetCardDetails(custInfo.AnnualIncome).FirstOrDefault();
                if (_cardDetails != null)
                {
                    CustomerCardDetailsVM cardInfo = new CustomerCardDetailsVM
                    {
                        Id = _cardDetails.Id,
                        CardName = _cardDetails.CardName,
                        AnnualPercentageRate = _cardDetails.AnnualPercentageRate,
                        PromoMessage = _cardDetails.PromoMessage,
                        IsEligible = custInfo.IsEligible,
                        CustomerFirstname = custInfo.FirstName,
                        CustomerLastName = custInfo.LastName

                    };
                    SaveCardData(cardInfo, custInfo);
                    return cardInfo; ;
                }

            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to fetch card details : {ex}");
                throw;
            }
            
            return null;         

        }

        /// <summary>
        /// To save Card data to database. After all validation this method will save card and customer data to the Database
        /// </summary>
        /// <param name="CustCardInfo"></param>
        /// <param name="custInfo"></param>
        private void SaveCardData(CustomerCardDetailsVM custCardInfo, CustomerDetailsVM custInfo)
        {
            try
            {
                CustomerCardDetails customerCardInfo = new CustomerCardDetails
                {
                    CardDetailsId = custCardInfo.Id,
                    CustomerId = custInfo.Id
                };

                _toolRepository.AddCustomerCardDetails(customerCardInfo);

                _toolRepository.SaveAll();

            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to save car data : {ex}");
                throw;
            }                    

        }

        #endregion 
    }
}
