﻿using PreQualTool.Models;
using PreQualTool.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PreQualTool.Services
{
    public interface IPreQualService
    {
        CustomerCardDetailsVM SubmitData(CustomerDetailsVM custInfo);

    }
}
