﻿using PreQualTool.Models;
using PreQualTool.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PreQualTool.Services
{
    /// <summary>
    /// Validate methos will validate the Age and will return result
    /// </summary>
    public class AgeValidator : Ivalidator
    {
        public bool Validate(CustomerDetailsVM custinfo)
        {
            DateTime CurrentDate = DateTime.Today;
            int Age = CurrentDate.Year - custinfo.DateOfBirth.Year;
            if (Age < 18)
            {
                return false;
            }

            return true;
            
        }
    }
}
