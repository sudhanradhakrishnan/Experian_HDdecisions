﻿using PreQualTool.Models;
using PreQualTool.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PreQualTool.Services
{
    public interface ICompositeValidator : Ivalidator
    {
    }/// <summary>
    /// Composite validation can handle basic validations. 
    /// </summary>
    public class CompositeValidator : ICompositeValidator
    {
        List<Ivalidator> _validators = new List<Ivalidator>();
        public CompositeValidator()
        {

            _validators.Add(new AgeValidator());
            // can add additional validators here
        }
        public bool Validate(CustomerDetailsVM custinfo)
        {            
            foreach (var validator in _validators)
            {
                if (!validator.Validate(custinfo))
                {
                    return false;
                }
            }
            return true;          
        }
    }
}
