﻿using PreQualTool.Services;
using PreQualTool.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PreQualTool.Data;

namespace Experian.Web.Controllers
{
    public class CustomerController : Controller
    {
        private readonly IPreQualService _preQualService;        

        #region Constructor
        
        public CustomerController(IPreQualService preQualService)
        {
            _preQualService = preQualService;
        }

        #endregion

        #region Methods        
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(CustomerDetailsVM customer)
        {
            CustomerCardDetailsVM _customerCardDtails = new CustomerCardDetailsVM();
            if (ModelState.IsValid)
            {
                _customerCardDtails =   _preQualService.SubmitData(customer);

            }
            if (_customerCardDtails.Id > 0 && _customerCardDtails.IsEligible == true)
            {
                return View("CreditCard", _customerCardDtails);
            }
            else
            {
                return View("CreditCard", _customerCardDtails);
            }
        }

        public IActionResult CreditCard()
        {
            return View();
        }

        #endregion
    }
}