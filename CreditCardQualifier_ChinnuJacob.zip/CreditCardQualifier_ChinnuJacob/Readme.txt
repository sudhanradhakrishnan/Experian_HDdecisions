Please find below steps to run application:

1.Open CreditQualifier.sql and execute queries to create database and tables in local machine's sql server management studio, because I added application connectionstring with server name as localhost. 
(If you run it any server, then you need to change connectionstring in appsettings.json with servername)

2.Open solution in visual studio (Done in VS2019) , build and run it.

3.Added unit tests in NUnit.

4.There is one more folder 'Manual Testing' in the drive which has manual testing screenshots.