Step 1 : Create a DB Namely [HDdecisions_DB]
		Script : CREATE DATABASE HDdecisions_DB;
Step 2 : Run the script from the file HDdecisions_DB.sql

Step 3 : Open the CreditCardsPreQualificationTool Solution in Microsoft Visual Studio Community 2019

		Developed in .Net Core 3.1

		Microsoft Visual Studio Community 2019
		Version 16.6.1
		Framework 4.8
		
Include Packages if needed  		

Step 4 : Packages needed
		System.Configuration.ConfigurationManager
		System.Data.SqlClient
		Microsoft.Extensions.Logging
		Microsoft.Extensions.Configuration
		
		 Packages for TEST Project
		 Microsoft.Extensions.Logging Version="3.1.6" 
         Microsoft.Extensions.Logging.Abstractions Version="3.1.6"
         Microsoft.Extensions.Logging.Console Version="3.1.6"
         Microsoft.Extensions.Logging.Debug Version="3.1.6" 
         Moq Version="4.14.5"
         nunit Version="3.12.0"
         NUnit3TestAdapter Version="3.15.1"
         Microsoft.NET.Test.Sdk Version="16.4.0"
		 
		 
