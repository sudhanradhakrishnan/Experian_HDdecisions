INSERT INTO [dbo].[CreditCard]
           ([Name]
           ,[APR]
           ,[PromotionalMessage]
           ,[AnnualIncomeLimit])
     VALUES
           ('Barclaycard'
           ,'20.9'
           ,'0% interest on purchases for up to 18 months from the date you open your account'
           ,30000)

INSERT INTO [dbo].[CreditCard]
           ([Name]
           ,[APR]
           ,[PromotionalMessage]
           ,[AnnualIncomeLimit])
     VALUES
           ('Vanquis card'
           ,'39.9'
           ,'Increase your credit limit after the fifth statement, subject to eligibility'
           ,0)
GO


