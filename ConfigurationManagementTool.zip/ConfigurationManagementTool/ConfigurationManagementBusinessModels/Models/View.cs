﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConfigurationManagementBusinessModels.Models
{
    class View
    {
    }
}
