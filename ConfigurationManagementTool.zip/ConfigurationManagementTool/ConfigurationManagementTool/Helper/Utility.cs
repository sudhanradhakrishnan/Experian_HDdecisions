﻿using ConfigurationManagementBusinessModels.Models;
using ConfigurationManagementTool.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConfigurationManagementTool.Helper
{
    public static class Utility
    {
       
          
    }
}
