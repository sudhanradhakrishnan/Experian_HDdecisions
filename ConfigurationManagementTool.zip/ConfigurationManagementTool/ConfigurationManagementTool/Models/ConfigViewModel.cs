﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConfigurationManagementTool.Models
{
    /// <summary>
    /// This View Model is to display who have checked the pre-qualification of credit card details
    /// </summary>
    public class ConfigViewModel
    {
             
    }
}
