﻿using CreditCardUtility.DataAccess.Repository.IRepository;
using CreditCardUtility.Models.DTO.CreditCardEligiblity;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace CreditCardUtility.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CCEligiblityController : ControllerBase
    {
        #region Variables
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<CCEligiblityController> _logger;
        #endregion
        #region c'tro
        public CCEligiblityController(IUnitOfWork unitOfWork,ILogger<CCEligiblityController> logger)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
        }
        #endregion
        #region AddUserAndGetCreditCardDetails
        /// <summary>
        /// Post method to add User details and get the available card for user
        /// </summary>
        /// <param name="userDetails"></param>
        /// <returns></returns>
        [HttpPost("CreditCardDetails")]
        public async Task<IActionResult> CreditCardDetails(UserDetailsRequestDTO userDetails)
        {
            try
            {           
                var response = await _unitOfWork.CreditCardEligiblity.AddCreditCardDetails(userDetails);
                if (response == null)
                {
                    return NotFound("Details not found");
                }
                return Ok(response);
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error Path - CreditCardDetails in CCEligiblity: Details- {ex.StackTrace}");
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

        }

        #endregion
        #region Startup
        [HttpGet("")]
        public IActionResult Get()
        {
            return Ok("Application Started");
        }
        #endregion
    }
}
