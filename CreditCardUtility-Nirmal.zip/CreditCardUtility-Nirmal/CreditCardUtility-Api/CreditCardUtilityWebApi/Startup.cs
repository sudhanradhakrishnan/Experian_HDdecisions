using AutoMapper;
using CreditCardUtility.DataAccess.Data;
using CreditCardUtility.DataAccess.Mapping;
using CreditCardUtility.DataAccess.Repository;
using CreditCardUtility.DataAccess.Repository.IRepository;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace CreditCardUtilityAoi
{
    public class Startup
    {
        #region C'tor
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        } 
        #endregion

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //Allow cross site access to api
            services.AddCors();
            //DB context 
            services.AddDbContext<AppDBContext>(options =>
                    options.UseSqlServer(
                    Configuration.GetConnectionString("DefaultConnection")));
            //Dependency injection for Unit of work
            services.AddScoped<IUnitOfWork, UnitOfWork>();
            
            services.AddControllers();
            //Auto mapper to map class automatically
            services.AddAutoMapper(c => c.AddProfile<AutoMapperProfile>(), typeof(Startup));


        }


        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            
            app.UseRouting();
            app.UseCors(x=>x.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
