﻿using Microsoft.EntityFrameworkCore;
using CreditCardUtility.DataAccess.Data;

using CreditCardUtility.DataAccess.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace CreditCardUtility.DataAccess.Repository
{
    public class Repository<T> : IRepository<T> where T:class 
    {
        #region Variables
        private readonly AppDBContext _db;
        internal DbSet<T> dbSet;
        #endregion
        #region C'tor
        public Repository(AppDBContext db)
        {
            _db = db;
            this.dbSet = _db.Set<T>();
        }
        #endregion
        #region Add
        /// <summary>
        /// Add values to table
        /// </summary>
        /// <param name="entity">Generic entity</param>
        public async void Add(T entity)
        {
            await dbSet.AddAsync(entity);
        }

        #endregion
        #region GetById
        /// <summary>
        /// Get by Values by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<ServiceResponse<T>> Get(int id)
        {
            ServiceResponse<T> serviceResponse = new ServiceResponse<T>();
            serviceResponse.Data = await dbSet.FindAsync(id);
            return serviceResponse;
        }

        #endregion
        #region GetAll
        /// <summary>
        /// Fetch all records based on condition
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="orderBy"></param>
        /// <param name="includeProperties"></param>
        /// <returns></returns>
        public async Task<ServiceResponse<IEnumerable<T>>> GetAll(Expression<Func<T, bool>> filter = null, Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null, string includeProperties = null)
        {
            ServiceResponse<IEnumerable<T>> serviceResponse = new ServiceResponse<IEnumerable<T>>();
            IQueryable<T> query = dbSet;

            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties != null)
            {
                foreach (var includeProp in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProp);
                }
            }

            if (orderBy != null)
            {
                serviceResponse.Data = await orderBy(query).ToListAsync();
            }
            serviceResponse.Data = await query.ToListAsync();
            return serviceResponse;
        }
        #endregion
        #region GetFirstOrDefault
        /// <summary>
        /// Get First or default value based on Condition
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="includeProperties"></param>
        /// <returns></returns>
        public async Task<T> GetFirstOrDefault(Expression<Func<T, bool>> filter = null, string includeProperties = null)
        {
            IQueryable<T> query = dbSet;

            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties != null)
            {
                foreach (var includeProp in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProp);
                }
            }
            return await query.FirstOrDefaultAsync();
        }

        #endregion
        #region RemoveByID
        /// <summary>
        /// Remove value from table based on ID
        /// </summary>
        /// <param name="id"></param>
        public void Remove(int id)
        {
            T entity = dbSet.Find(id);
            Remove(entity);
        }
        #endregion
        #region RemoveBasedOnentity
        /// <summary>
        /// Remove based on entity
        /// </summary>
        /// <param name="entity"></param>
        public void Remove(T entity)
        {
            dbSet.Remove(entity);
        }

        #endregion
        #region RemoveRange
        /// <summary>
        /// Remove based on range
        /// </summary>
        /// <param name="entity"></param>
        public void RemoveRange(IEnumerable<T> entity)
        {
            dbSet.RemoveRange(entity);
        }

        #endregion
    }
}
