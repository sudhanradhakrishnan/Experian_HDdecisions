﻿using AutoMapper;
using CreditCardUtility.DataAccess.Data;
using CreditCardUtility.DataAccess.Repository.IRepository;
using System;
using System.Collections.Generic;
using System.Text;

namespace CreditCardUtility.DataAccess.Repository
{
    /// <summary>
    /// Class that is available to Controller
    /// </summary>
    public class UnitOfWork : IUnitOfWork
    {

        #region Variables
        private readonly AppDBContext _db;
        private readonly IMapper _mapper;
        #endregion
        #region C'tor
        public UnitOfWork(AppDBContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
            CreditCardEligiblity = new CreditCardEligiblityRepository(db, mapper);

        } 
        #endregion
        public ICreditCardEligiblityRepository CreditCardEligiblity { get; private set; }
        public IStoredProcedures SPCalls { get; set; }
        //Save
        public void Save()
        {
            _db.SaveChanges();
        }
        //Clean up
        public void Dispose()
        {
            _db.Dispose();
        }

    }
}
