﻿using AutoMapper;
using CreditCardUtility.DataAccess.Data;
using CreditCardUtility.DataAccess.Repository.IRepository;
using CreditCardUtility.Models.DTO.CreditCardEligiblity;
using CreditCardUtility.Models.Enum;
using CreditCardUtility.Models.Models;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace CreditCardUtility.DataAccess.Repository
{
    class CreditCardEligiblityRepository:Repository<UsersCreditCardEligiblity>,ICreditCardEligiblityRepository
    {
        #region variables
        private readonly AppDBContext _db;
        private readonly IMapper _mapper;
        #endregion
        #region c'tor
        public CreditCardEligiblityRepository(AppDBContext db, IMapper mapper) :base(db)
        {
            _db = db;
            _mapper = mapper;
        }
        #endregion
        #region FetchEligibleCreditCards
        public async Task<CreditCardResponseVMDTO> AddCreditCardDetails(UserDetailsRequestDTO userDetail)
        {
            CreditCardResponseVMDTO creditCardResponse = new CreditCardResponseVMDTO();
            var cardType = GetCardType(userDetail);
            var mappedresult = _mapper.Map<UsersCreditCardEligiblity>(userDetail);
            mappedresult.CreditCardTypeID = cardType.CreditCardTypeID;

            Add(mappedresult);
            await _db.SaveChangesAsync();
            creditCardResponse.CreditCardType = cardType;
            creditCardResponse.validCard = cardType.CreditCardTypeID == 1 ? false : true;
            return creditCardResponse;
        }

        //Get Card Type based on user details
        private CreditCardType GetCardType(UserDetailsRequestDTO userDetails)
        {
            int cardType = 1;
            int age = GetUserAge(userDetails.DOB);
            if (age < 18)
            {
                cardType = Convert.ToInt32(Cards.NoCard);
            }
            else if (userDetails.AnnualIncome > 30000)
            {
                cardType = Convert.ToInt32(Cards.BarclayCard);
            }
            else
            {
                cardType = Convert.ToInt32(Cards.VanquisCard);
            }
            return _db.CreditCardType.FirstOrDefault(x => x.CreditCardTypeID == cardType);
        }
        //Get User Age based on User details
        private int GetUserAge(DateTime dob)
        {
            int age = 0;
            age = DateTime.Now.Year - dob.Year;
            if (DateTime.Now.Month < dob.Month)
            {
                age--;
            }
            return age;
        } 
        #endregion
    }
}
