﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CreditCardUtility.DataAccess.Repository.IRepository
{

    
    public interface IUnitOfWork:IDisposable
    {
        public ICreditCardEligiblityRepository CreditCardEligiblity { get; }
        public IStoredProcedures SPCalls { get; }
        void Save();
    }
}
