﻿using CreditCardUtility.Models.DTO.CreditCardEligiblity;
using CreditCardUtility.Models.Models;
using System.Threading.Tasks;

namespace CreditCardUtility.DataAccess.Repository.IRepository
{
    public interface ICreditCardEligiblityRepository:IRepository<UsersCreditCardEligiblity>
    {
        Task<CreditCardResponseVMDTO> AddCreditCardDetails(UserDetailsRequestDTO userDetails);               
    }
}
