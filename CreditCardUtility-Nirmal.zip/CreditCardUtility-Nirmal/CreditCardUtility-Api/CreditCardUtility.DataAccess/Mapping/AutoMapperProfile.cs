﻿using AutoMapper;
using CreditCardUtility.Models.DTO.CreditCardEligiblity;
using CreditCardUtility.Models.Models;


namespace CreditCardUtility.DataAccess.Mapping
{
    
    public class AutoMapperProfile:Profile
    {
        #region c'tor
        public AutoMapperProfile()
        {
            CreateMap<UserDetailsRequestDTO, UsersCreditCardEligiblity>();
        }
        #endregion
    }
}
