﻿using CreditCardUtility.Models.Models;
using Microsoft.EntityFrameworkCore;

namespace CreditCardUtility.DataAccess.Data
{
    public class AppDBContext: DbContext
    {
        #region c'tor
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
        {

        }
        #endregion
        #region DbSet
        public DbSet<CreditCardType> CreditCardType { get; set; }
        public DbSet<UsersCreditCardEligiblity>  UsersCreditCardEligiblities { get; set; }
        #endregion
        #region Seedingvaluestotable
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            modelBuilder.Entity<CreditCardType>().HasData(
                new CreditCardType { 
                    CreditCardTypeID=1,
                    CreditCardName= "No credit cards are available",
                    CreditCardImage="",
                    APRDetails="",
                    PromotionMessage=""
                },
                new CreditCardType
                {
                    CreditCardTypeID = 2,
                    CreditCardName = "Barclaycard Credit Card",
                    CreditCardImage = "./assets/images/Barclaycard.png",
                    APRDetails = "33.9% APR (variable)",
                    PromotionMessage = "The issuer offers serveral great products in partnership with major airlines,hotels and retailers."
                },
                new CreditCardType
                {
                    CreditCardTypeID = 3,
                    CreditCardName = "Vanquis Card",
                    CreditCardImage = "./assets/images/Vanquiscard.png",
                    APRDetails = "39.9% APR (variable)",
                    PromotionMessage = "Credit Card comes with serveral features design to help people on their credit-building Journey"
                }
                );
        }
        #endregion
    }

}
