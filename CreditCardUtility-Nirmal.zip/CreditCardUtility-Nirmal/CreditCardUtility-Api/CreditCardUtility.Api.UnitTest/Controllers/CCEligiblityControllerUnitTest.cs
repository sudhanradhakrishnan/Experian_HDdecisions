﻿using CreditCardUtility.Api.Controllers;
using CreditCardUtility.DataAccess.Repository.IRepository;
using CreditCardUtility.Models.DTO.CreditCardEligiblity;
using CreditCardUtility.Models.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Net;
using System.Threading.Tasks;

namespace CreditCardUtility.Api.UnitTest.Controllers
{
    [TestClass]
    public  class CCEligiblityControllerUnitTest
    {
        
        private CreditCardResponseVMDTO GetFakeDateNoCreditCard()
        {
            CreditCardResponseVMDTO responseVMDTO = new CreditCardResponseVMDTO();
            CreditCardType cardType = new CreditCardType
                {
                CreditCardTypeID = 1,
                CreditCardName = "No credit cards are available",
                CreditCardImage = "",
                APRDetails = "",
                PromotionMessage = ""
            };

            responseVMDTO.CreditCardType = cardType;
            responseVMDTO.validCard = false;
            return responseVMDTO;
        }
       

        [TestMethod]
        public async Task TestValidationForAddCreditCardDetails()
        {

            //Adding dependency
            var service = new Mock<IUnitOfWork>();
            var log = new Mock<ILogger<CCEligiblityController>>();
            var dummy = GetFakeDateNoCreditCard();
            //Expected Results
            CreditCardResponseVMDTO ExpectedResult = new CreditCardResponseVMDTO();
            CreditCardType cardType = new CreditCardType { 
                    CreditCardTypeID = 1,
                    CreditCardName = "No credit cards are available",
                    CreditCardImage = "",
                    APRDetails = "",
                    PromotionMessage = ""};

            ExpectedResult.CreditCardType = cardType;
            ExpectedResult.validCard = false;
            
            //Input passing value
            var userDetail =new UserDetailsRequestDTO { 
                 FirstName="test1",
                 LastName="test2",
                 DOB= Convert.ToDateTime("2020-01-01"),
                 AnnualIncome=55555
            } ;

            //setting up Mock values
            service.Setup(x => x.CreditCardEligiblity.AddCreditCardDetails(It.IsAny<UserDetailsRequestDTO>())).ReturnsAsync(dummy);
          
            //initiating Controller
            CCEligiblityController cCEligiblityController = new CCEligiblityController(service.Object, log.Object);
            //result  
            var actionResult = await cCEligiblityController.CreditCardDetails(userDetail);
            var result = actionResult as OkObjectResult;
            
            //test scenerio
            Assert.AreEqual((int)HttpStatusCode.OK, result.StatusCode);
            Assert.AreEqual(ExpectedResult.CreditCardType.CreditCardTypeID, ((CreditCardResponseVMDTO)result.Value).CreditCardType.CreditCardTypeID);

        }
    }       
}
