﻿namespace CreditCardUtility.Models.Enum
{
    //Available Card types
    public enum Cards
    {
        NoCard=1,
        BarclayCard=2,
        VanquisCard=3

    }
}
