﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CreditCardUtility.Models.Models
{
    #region UsersCreditCardEligiblity
    /// <summary>
    /// Class To store the detail of person who check eligibile card for them
    /// </summary>
    public class UsersCreditCardEligiblity
    {
        #region Fields
        [Key]
        public int Id { get; set; }
        [Required]
        [MaxLength(50)]
        public string FirstName { get; set; }
        [Required]
        [MaxLength(50)]
        public string LastName { get; set; }
        [Required]
        public DateTime DOB { get; set; }
        [Required]
        public float AnnualIncome { get; set; }

        public DateTime CreatedOn { get; set; } = DateTime.Now;

        [ForeignKey("TypeOfCreditCards")]
        public int CreditCardTypeID { get; set; }
        public CreditCardType TypeOfCreditCards { get; set; } 
        #endregion
    }
    #endregion
}
