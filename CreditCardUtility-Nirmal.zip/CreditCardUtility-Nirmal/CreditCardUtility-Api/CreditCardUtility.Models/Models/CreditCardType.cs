﻿using System.ComponentModel.DataAnnotations;

namespace CreditCardUtility.Models.Models
{
    #region CreditCardType
    /// <summary>
    /// Table to Store Credit Card type
    /// </summary>

    public class CreditCardType
    {
        #region Fields
        [Key]
        public int CreditCardTypeID { get; set; }
        [Required]
        [MaxLength(30)]
        public string CreditCardName { get; set; }
        [MaxLength(50)]
        public string CreditCardImage { get; set; }
        [MaxLength(150)]
        [Required]
        public string APRDetails { get; set; }
        [MaxLength(250)]
        public string PromotionMessage { get; set; }
        #endregion
    }    
    #endregion
}
