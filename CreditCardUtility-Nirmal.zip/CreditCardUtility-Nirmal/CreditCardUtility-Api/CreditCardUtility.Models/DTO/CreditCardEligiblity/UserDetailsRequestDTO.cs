﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CreditCardUtility.Models.DTO.CreditCardEligiblity
{
    #region UserDetailsRequest
    /// <summary>
    /// DTO To get the detail of user
    /// </summary>
    public class UserDetailsRequestDTO
    {
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public DateTime DOB { get; set; }
        [Required]
        public float AnnualIncome { get; set; }
    }
    #endregion
}
