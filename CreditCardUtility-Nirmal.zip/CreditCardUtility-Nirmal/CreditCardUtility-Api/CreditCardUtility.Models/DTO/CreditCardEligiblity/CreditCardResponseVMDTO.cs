﻿using CreditCardUtility.Models.Models;

namespace CreditCardUtility.Models.DTO.CreditCardEligiblity
{
    #region CreditCardResponseViewModel
    /// <summary>
    /// View model to send Response to user
    /// </summary>
    public class CreditCardResponseVMDTO
    {
        public CreditCardType CreditCardType { get; set; }
        public bool validCard { get; set; }
    }
    #endregion
}
