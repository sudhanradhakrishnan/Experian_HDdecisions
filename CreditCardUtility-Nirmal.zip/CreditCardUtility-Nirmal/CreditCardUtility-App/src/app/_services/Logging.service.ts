export class LoggingService{
    logStatus(message: string){
        const currentDate = new Date();
        console.log(`${currentDate}` , message);
    }
}
