import { Component, OnInit } from '@angular/core';
import { CreditCardService } from '../_services/credit-card.service';
import { FormBuilder, Validators, FormControl, FormGroup } from '@angular/forms';
import { LoggingService } from '../_services/logging.service';

@Component({
  selector: 'app-credit-card',
  templateUrl: './credit-card.component.html',
  styleUrls: ['./credit-card.component.css']
})
export class CreditCardComponent implements OnInit {
  CreditCardForm: FormGroup;
  submitted = false;
  resp: any = {};
  isHidden = false;
  constructor(private builder: FormBuilder, private creditCardService: CreditCardService, private logging: LoggingService){}

  ngOnInit(): void {
    this.CreditCardForm = this.builder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      DOB: ['', Validators.required],
      annualIncome: ['', Validators.required]

    });
  }
  get f() { return this.CreditCardForm.controls; }
  onSubmit(CreditCardForm: any){
    this.isHidden = false;
    this.submitted = true;
    if (CreditCardForm.invalid) {
        return;
    }    
    this.creditCardService.CheckCreditCard(CreditCardForm.value).subscribe(
     next => {
       this.resp = next;
       this.isHidden = true;
     }, error => {
        this.logging.logStatus(error); });
  }
  onReset(){
    this.isHidden = false;
    this.submitted = false;
    this.CreditCardForm.reset();
  }
}
