﻿namespace CardPro.UI.Business.Configurations
{
    public class CardProAPIConfiguration
    {
        /// <summary>
        /// CardPro API Url
        /// </summary>
        public string APIUrl { get; set; }
    }
}