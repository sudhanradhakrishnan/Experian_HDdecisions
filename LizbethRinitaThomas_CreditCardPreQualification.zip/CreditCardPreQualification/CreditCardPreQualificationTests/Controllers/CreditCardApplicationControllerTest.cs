﻿using Moq;
using CreditCardPreQualification.Business.Services;
using CreditCardPreQualification.Controllers;
using AutoMapper;
using Microsoft.Extensions.Logging;
using Xunit;
using Microsoft.AspNetCore.Mvc;
using CreditCardPreQualification;
using CreditCardPreQualification.Data.Entities;
using System.Threading.Tasks;

namespace CreditCardPreQualificationTests.Controllers
{
    public class CreditCardApplicationControllerTest
    {
        private readonly Mock<IApplicantService> _mockService;
        private readonly CreditCardApplicationController _controller;
        private readonly IMapper _mockmapper;
        private readonly Mock<ILogger<CreditCardApplicationController>> _mocklogger;

        public CreditCardApplicationControllerTest()
        {
            var mockMapper = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new AutoMapperProfile());
            });
            var mapper = mockMapper.CreateMapper();
            _mockService = new Mock<IApplicantService>();
            _mockmapper = mapper;
            _mocklogger = new Mock<ILogger<CreditCardApplicationController>>();
            _controller = new CreditCardApplicationController(_mockService.Object,_mocklogger.Object,_mockmapper);
        }
        /// <summary>
        /// Test for Home page if it returns view
        /// </summary>
        [Fact]
        public void Index_ActionExecutes_ReturnsViewForIndex()
        {
            var result = _controller.Index();
            Assert.IsType<ViewResult>(result);
        }

        /// <summary>
        /// Displays credit card detail view with xpected credit card
        /// </summary>
        /// <returns></returns>
        [Fact]
        public async Task CreditCardDetail_ReturnsVanquis()
        {
            var detail = new CreditCardDetail { Id = 2, CreditCardName = "Vanquis", Message = "A flexible card you can use for balance transfers and purchases.", APR = 39.90m };
            
            _mockService.Setup(x => x.GetCardById(2)).Returns(Task.FromResult(detail));
            var result = await _controller.CreditCardDetail(2);
            var viewResult = Assert.IsType<ViewResult>(result);
            var returndetail = Assert.IsType<CreditCardDetail>(viewResult.Model);
            Assert.Equal("Vanquis", returndetail.CreditCardName);
        }
    }
}
