﻿using AutoMapper;
using CreditCardPreQualification.Data.Entities;
using CreditCardPreQualification.Models;

namespace CreditCardPreQualification
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<ApplicantModel, CreditCardApplicant>();
        }
    }
}