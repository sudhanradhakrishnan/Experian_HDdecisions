﻿using System.Threading.Tasks;
using AutoMapper;
using CreditCardPreQualification.Business.Services;
using CreditCardPreQualification.Data.Entities;
using CreditCardPreQualification.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace CreditCardPreQualification.Controllers
{
    public class CreditCardApplicationController : Controller
    {
        private readonly IApplicantService _applicantService;
        private readonly IMapper _mapper;
        private readonly ILogger<CreditCardApplicationController> _logger;

        public CreditCardApplicationController(IApplicantService applicantService, ILogger<CreditCardApplicationController> logger,IMapper mapper)
        {
            this._applicantService = applicantService;
            this._logger = logger;
            this._mapper = mapper;
        }

        /// <summary>
        /// Displays Applicant Form
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            return View(new ApplicantModel());
        }

        /// <summary>
        /// Add Applicant to the system and assigns appopriate credit card to the applicant
        /// </summary>
        /// <param name="cardUser"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Create(ApplicantModel model)
        {
            if (ModelState.IsValid)
            {
                ////Maps Applicant model to CreditCardApplicant
                CreditCardApplicant applicant = _mapper.Map<CreditCardApplicant>(model);
                var newapplicant = await _applicantService.AddApplicant(applicant);
                _logger.LogInformation("new Applicant {0} with credit card {1}", applicant.FirstName,applicant.CreditCardDetail.CreditCardName);

                //return to card view based on applicant criteria
                return RedirectToAction("CreditCardDetail", new { creditCardId = newapplicant.CreditCardDetailId });
            }
            return View("Index");
        }

        /// <summary>
        /// Get Available Card for Applicant
        /// </summary>
        /// <param name="applicantId"></param>
        /// <returns></returns>
        public async Task<IActionResult> CreditCardDetail(int CreditCardId)
        {
            ///getting card detail after creating applicant
            var CreditCardDetail = await _applicantService.GetCardById(CreditCardId);
            _logger.LogInformation("CreditCardDetail for {0}", CreditCardId);
            return View(CreditCardDetail);
           
        }
    }
}