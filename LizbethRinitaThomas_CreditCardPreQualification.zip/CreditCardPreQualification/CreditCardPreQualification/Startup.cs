﻿using AutoMapper;
using CreditCardPreQualification.Business.Services;
using CreditCardPreQualification.Data.DataAccess;
using CreditCardPreQualification.Data.Repositories;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace CreditCardPreQualification
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });
            //////Registering service types
            services.AddScoped<CreditCardApplicantRepository>();
            services.AddScoped<CreditCardDetailRepository>();

            services.AddScoped<IApplicantService,ApplicantService >();
            
            ///////Registering Automapper
            services.AddAutoMapper(typeof(AutoMapperProfile).Assembly);

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
            services.AddDbContext<CreditCardPreQualificationContext>(options =>
       options.UseSqlServer(Configuration.GetConnectionString("PreQualificationConnection")));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                /////Show error page for status code exceptions
                app.UseStatusCodePagesWithReExecute("/Error/{0}");
                
                /////Global exception handling
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=CreditCardApplication}/{action=Index}/{id?}");
            });
        }
    }
}
