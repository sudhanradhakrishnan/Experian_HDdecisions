# CreditCardPreQualification

This project was developed using visual studio 2017 .Net Core 2.1, this application uses MVC Core andEntity Framework Core CodeFirst.Running the application will create database.

Connection String which is set in appsettings.json given below

 "PreQualificationConnection": "Server=(LocalDb)\\MSSQLLocalDb;Database=PreQualification;Trusted_Connection=True;MultipleActiveResultSets=true"




