﻿using CreditCardPreQualification.Data.Entities;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using CreditCardPreQualification.Data.Repositories;
using Microsoft.Extensions.Logging;

namespace CreditCardPreQualification.Business.Services
{
    public class ApplicantService : IApplicantService
    {
        private readonly ILogger<ApplicantService> _logger;
        private readonly CreditCardDetailRepository _detailrepo;
        private readonly CreditCardApplicantRepository _applicantRepo;
        public ApplicantService(CreditCardDetailRepository detailrepo, CreditCardApplicantRepository applicantRepo, ILogger<ApplicantService> logger)
        {
            _detailrepo = detailrepo;
            _applicantRepo = applicantRepo;
            _logger = logger;
        }
        /// <summary>
        /// Adds applicant to database based on criteria,appropriate credit card also set to applicant
        /// </summary>
        /// <param name="applicant"></param>
        /// <returns>CreditCardApplicant</returns>
        public async Task<CreditCardApplicant> AddApplicant(CreditCardApplicant applicant)
        {
            CreditCardApplicant validapplicant = await ValidateApplicantCriteria(applicant);
            _logger.LogInformation("ApplicantService AddApplicant {0}", applicant);

            return await _applicantRepo.Add(applicant);
        }

        /// <summary>
        /// Get all credit card details
        /// </summary>
        /// <returns>ICollection<CreditCardDetail></returns>
        public async Task<ICollection<CreditCardDetail>> GetAllCreditCards()
        {
            return await _detailrepo.GetAll();
        }

        /// <summary>
        /// Setting appropriate card based on age and annual income criteria of applicant
        /// </summary>
        /// <param name="model"></param>
        /// <returns>CreditCardApplicant</returns>
        private async Task<CreditCardApplicant> ValidateApplicantCriteria(CreditCardApplicant model)
        {
            CreditCardApplicant applicant = model;
            _logger.LogInformation("Applicantservice ValidateApplicantCriteria age {0} income {1}", model.Age, model.AnnualIncome);
            //get credit card which have age and income greater than applicant's
            CreditCardDetail cardDetail = _detailrepo.CardByAgeIncome(applicant.Age,applicant.AnnualIncome);

            if (cardDetail == null)
            {
                ///Applicant shouldhave minimum age criteria
                _logger.LogInformation("Applicantservice Age income criteria failed ");

                cardDetail = _detailrepo.CardByAge(applicant.Age, applicant.AnnualIncome);
            }
                _logger.LogInformation("cardDetail name {0} ", cardDetail.CreditCardName);

            applicant.CreditCardDetail = cardDetail;
            applicant.Status = Status.Created;
            return applicant;
        }

        /// <summary>
        /// Get CreditCardDetail By CardId
        /// </summary>
        /// <param name="CardId"></param>
        /// <returns>CreditCardDetail</returns>
        public async Task<CreditCardDetail> GetCardById(int CardId)
        {
            return await _detailrepo.GetById(CardId);
        }
    }
}
