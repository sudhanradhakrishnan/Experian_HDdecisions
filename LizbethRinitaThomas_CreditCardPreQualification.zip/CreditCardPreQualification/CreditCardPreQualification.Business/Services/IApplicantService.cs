﻿using CreditCardPreQualification.Data.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CreditCardPreQualification.Business.Services
{
    public interface IApplicantService
    {
        Task<CreditCardApplicant> AddApplicant(CreditCardApplicant applicant);
        Task<ICollection<CreditCardDetail>> GetAllCreditCards();
        Task<CreditCardDetail> GetCardById(int CardId);
    }
}
