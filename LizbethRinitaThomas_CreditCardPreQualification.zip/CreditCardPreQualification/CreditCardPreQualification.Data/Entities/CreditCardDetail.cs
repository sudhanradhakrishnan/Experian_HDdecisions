﻿using System.ComponentModel.DataAnnotations;

namespace CreditCardPreQualification.Data.Entities
{
    public class CreditCardDetail :IEntity
    {
        public int Id { get; set; }
        public string CreditCardName { get; set; }
        public string Message { get; set; }
        public decimal APR { get; set; }
        public int? minAge { get; set; }
        public int? minIncome { get; set; }
    }
}
