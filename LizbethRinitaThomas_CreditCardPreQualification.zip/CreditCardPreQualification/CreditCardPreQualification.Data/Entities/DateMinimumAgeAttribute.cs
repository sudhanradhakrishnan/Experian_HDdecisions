﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace CreditCardPreQualification.Data.Entities
{
    public class DateMinimumAgeAttribute : ValidationAttribute
    {
        public DateMinimumAgeAttribute(int minimumAge)
        {
            MinimumAge = minimumAge;
            ErrorMessage = "{0} must be someone at least {1} years of age";
        }

        public override bool IsValid(object value)
        {
            DateTime date;
            if (value == null)
                return true;
            if ((value != null && DateTime.TryParse(value.ToString(), out date)))
            {
                return date.AddYears(MinimumAge) < DateTime.Now;
            }

            return false;
        }

        /// <summary>
        /// Returns validation message after validating DOB field
        /// </summary>
        /// <param name="value"></param>
        /// <param name="validationContext"></param>
        /// <returns></returns>
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            DateTime date;
            if ((value != null && DateTime.TryParse(value.ToString(), out date)))
            {
                ////Date of birth should not be future date
                if (date >= DateTime.Now) //Dates Greater than or equal to today are valid (true)
                    return new ValidationResult("Date of Birth cannot be future date");
                ////Age should be min 18 for applying credit card
                if (date.AddYears(MinimumAge) > DateTime.Now)
                    return new ValidationResult("No credit cards are available , Applicant must be at least " + MinimumAge + " years of age");

                
            }
            return null;
        }

        public override string FormatErrorMessage(string name)
        {
            return string.Format(ErrorMessageString, name, MinimumAge);
        }

        public int MinimumAge { get; }
    }
}
