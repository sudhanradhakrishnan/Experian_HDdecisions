﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CreditCardPreQualification.Data.Entities
{
    public enum Status
    {
        Created=1,

        Deleted=0
    }
    public class CreditCardApplicant :IEntity
    {
       
        public CreditCardApplicant()
        {
            CreatedDate = DateTime.Now;
        }
        public int Id { get; set; }

        [Required]
        [StringLength(20, ErrorMessage = "The First Name should not exceed 20 characters")]
        public string FirstName { get; set; }

        [StringLength(20, ErrorMessage = "The Last Name should not exceed 20 characters")]
        public string LastName { get; set; }

        [DateMinimumAge(18, ErrorMessage = "No credit cards are available , Applicant must be at least {1} years of age")]
        [Required(ErrorMessage = "Date Of Birth is Required")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
        [DataType(DataType.Date)]
        public DateTime? DateOfBirth { get; set; }

        
        public int Age
        {
            get { return (DateOfBirth.HasValue)? (DateTime.Today.Year - DateOfBirth.Value.Year):0; }
            set
            {
                value= (DateOfBirth.HasValue) ? (DateTime.Today.Year - DateOfBirth.Value.Year) : 0;
            }
        }

        [Required]
        [DataType(DataType.Currency)]
        [Range(0, 9999999999999999.99, ErrorMessage = "Invalid Annual Income, Max 18 digits")]
        public decimal? AnnualIncome { get; set; }

        public DateTime CreatedDate { get; set; }

        public Status Status { get; set; }

        public int CreditCardDetailId { get; set; }

        public CreditCardDetail CreditCardDetail { get; set; }
    }
}
