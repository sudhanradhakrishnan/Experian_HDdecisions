﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CreditCardPreQualification.Data.Entities
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
