﻿using CreditCardPreQualification.Data.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CreditCardPreQualification.Data.Repositories
{
    public class EfCoreRepository<TEntity, TContext> : IRepository<TEntity>
       where TEntity : class, IEntity
       where TContext : DbContext
    {
        private readonly TContext context;
        public EfCoreRepository(TContext context)
        {
            this.context = context;
        }

        /// <summary>
        /// Basic Operations to database based on entity
        /// </summary>
        
        
        public async Task<TEntity> Add(TEntity entity)
        {
            context.Set<TEntity>().Add(entity);
            await context.SaveChangesAsync();
            return entity;
        }

        public async Task<TEntity> GetById(int id)
        {
            return await context.Set<TEntity>().FindAsync(id);
        }

        public async Task<ICollection<TEntity>> GetAll()
        {
            return await context.Set<TEntity>().ToListAsync();
        }

        
    }

}
