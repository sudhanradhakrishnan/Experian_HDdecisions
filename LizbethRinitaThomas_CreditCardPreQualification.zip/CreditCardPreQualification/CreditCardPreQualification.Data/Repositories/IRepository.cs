﻿using CreditCardPreQualification.Data.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CreditCardPreQualification.Data.Repositories
{
    public interface IRepository<T> where T : class, IEntity
    {
        Task<ICollection<T>> GetAll();
        Task<T> GetById(int id);
        Task<T> Add(T entity);
    }
}
