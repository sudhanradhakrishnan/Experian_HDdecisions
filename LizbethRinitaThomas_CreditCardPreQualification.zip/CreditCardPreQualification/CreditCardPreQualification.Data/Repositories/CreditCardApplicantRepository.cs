﻿using CreditCardPreQualification.Data.DataAccess;
using CreditCardPreQualification.Data.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Linq;
using System.Threading.Tasks;

namespace CreditCardPreQualification.Data.Repositories
{
    public class CreditCardApplicantRepository : EfCoreRepository<CreditCardApplicant, CreditCardPreQualificationContext>
    {
        private readonly ILogger<CreditCardApplicantRepository> _logger;

        public CreditCardApplicantRepository(CreditCardPreQualificationContext context, ILogger<CreditCardApplicantRepository> logger) : base(context)
        {
            this._logger = logger;
        }
        // We can add new methods specific to the CreditCardApplicantRepository repository here in the future
        
    }
}
