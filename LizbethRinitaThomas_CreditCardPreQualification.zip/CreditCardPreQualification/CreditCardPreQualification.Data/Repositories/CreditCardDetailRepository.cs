﻿using CreditCardPreQualification.Data.DataAccess;
using CreditCardPreQualification.Data.Entities;
using Microsoft.Extensions.Logging;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CreditCardPreQualification.Data.Repositories
{
    public class CreditCardDetailRepository : EfCoreRepository<CreditCardDetail, CreditCardPreQualificationContext>
    {
        private readonly ILogger<CreditCardDetailRepository> _logger;
        private readonly CreditCardPreQualificationContext _context;

        public CreditCardDetailRepository(CreditCardPreQualificationContext context, ILogger<CreditCardDetailRepository> logger) : base(context)
        {
            this._logger = logger;
            this._context = context;
        }

        /// <summary>
        /// Minimum age Income criteria
        /// </summary>
        /// <param name="age"></param>
        /// <param name="income"></param>
        /// <returns>CreditCardDetail</returns>
        public CreditCardDetail CardByAgeIncome(int age,decimal? income)
        {
            return  _context.CreditCardDetails.Where(x => x.minAge < age && x.minIncome < income.Value).FirstOrDefault();
        }

        /// <summary>
        /// Minimum Age Criteria
        /// </summary>
        /// <param name="age"></param>
        /// <param name="income"></param>
        /// <returns>CreditCardDetail</returns>
        public CreditCardDetail CardByAge(int age, decimal? income)
        {
            return _context.CreditCardDetails.Where(x => x.minAge < age && x.minIncome ==null).FirstOrDefault();
        }
    }
}
