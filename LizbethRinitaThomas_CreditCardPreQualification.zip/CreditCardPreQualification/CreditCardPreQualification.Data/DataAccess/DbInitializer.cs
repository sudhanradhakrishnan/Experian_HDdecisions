﻿using CreditCardPreQualification.Data.Entities;
using System.Linq;

namespace CreditCardPreQualification.Data.DataAccess
{
    public class DbInitializer
    {
        /// <summary>
        /// This method Seed Credit Cards to database
        /// </summary>
        /// <param name="context"></param>
        public static void Initialize(CreditCardPreQualificationContext context)
        {
            context.Database.EnsureCreated();

            // Look for any students.
            if (context.CreditCardDetails.Any())
            {
                return;   // DB has been seeded
            }

            var creditCardDetails = new CreditCardDetail[]
            {
            new CreditCardDetail{CreditCardName="Barclaycard",Message="Good for earning cashback on your purchases",minAge=18,APR=20.9m},
            new CreditCardDetail{CreditCardName="Vanquis",Message="A flexible card you can use for balance transfers and purchases.",minAge=18,minIncome=30000,APR=39.9m},
            };
            foreach (CreditCardDetail s in creditCardDetails)
            {
                context.CreditCardDetails.Add(s);
            }
            context.SaveChanges();
        
           

        }
    }
}

    

