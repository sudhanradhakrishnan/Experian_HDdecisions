﻿using CreditCardPreQualification.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace CreditCardPreQualification.Data.DataAccess
{
    public class CreditCardPreQualificationContext:DbContext
    {
        public CreditCardPreQualificationContext(DbContextOptions<CreditCardPreQualificationContext> options) : base(options)
        {
        }

        public DbSet<CreditCardApplicant> CreditCardApplicants { get; set; }
        public DbSet<CreditCardDetail> CreditCardDetails { get; set; }
    }
}
