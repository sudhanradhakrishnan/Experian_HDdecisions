﻿using CreditCard.BL;
using CreditCard.Model;
using CreditCard.Service;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CreditCard.MVC.Web.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        ILog logger = LogManager.GetLogger(typeof(HomeController));  //Declaring Log4Net  

        private UserInfoService objUserInfoService;

        //Dependency Injection
        public HomeController(IUserInfoBL objIUserInfoBL)
        {
            objUserInfoService = new UserInfoService(objIUserInfoBL);
        }

        /// <summary>
        /// Create Action 
        /// </summary>
        /// <returns></returns>
        public ActionResult Create()
        {
            return View();
        }

        #region Adding User Information on Create Action      
        /// <summary>
        ///  Adding User info for credit card pre qualification.
        /// </summary>
        /// <param name="objUserInfo"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Model.UserInfo objUserInfo)
        {
            try
            {
                if (ModelState.IsValid) 
                {
                    objUserInfoService.AddUser(objUserInfo); //Adding User Information
                    TempData["User"] = objUserInfo; //Storing the data                   
                    return RedirectToAction("Results"); //Redirecting to Results Action                  
                }

                return View(objUserInfo);
            }
            catch (Exception ex)
            {
                logger.Error(ex.ToString()); //Logging error
                return View("Error"); //Redirecting to Error page
            }
        }
        #endregion

        #region Result Status on Results Action 
        public ActionResult Results()
        {
            try
            {
                if (TempData.ContainsKey("User"))
                {
                    UserInfo objUserInfo = TempData["User"] as UserInfo; // Retreiving the data 
                    return View(objUserInfo); //Redirecting to Results View  
                }
                else
                {   // Redirecting to Home/Create 
                    return RedirectToRoute(new
                    {
                        controller = "Home",
                        action = "Create"
                    });
                }
                
            }
            catch (Exception ex)
            {
                logger.Error(ex.ToString()); //Logging error
                return View("Error"); //Redirecting to Error page
            }

        }
        #endregion

    }
}