﻿using CreditCard.Model;

namespace CreditCard.BL
{
    public interface IUserInfoBL
    {
        /// <summary>
        /// Adding User info for credit card pre qualification.
        /// </summary>
        /// <param name="objUserInfo"></param>
        /// <returns></returns>
        bool AddUser(UserInfo objUserInfo);        
    }
}
