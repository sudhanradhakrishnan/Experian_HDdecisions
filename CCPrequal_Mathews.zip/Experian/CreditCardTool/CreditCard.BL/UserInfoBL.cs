﻿using CreditCard.Data;
using CreditCard.Model;
using System;

namespace CreditCard.BL
{
    public class UserInfoBL : IUserInfoBL
    {
        private modelEntities objCreditCardToolEntity;
        public UserInfoBL()
        {
            objCreditCardToolEntity = new modelEntities();
        }

        #region Age Calculation
        /// <summary>
        /// Calculating Age from Date of Birth
        /// </summary>
        /// <param name="DOB"></param>
        /// <returns></returns>
        public int CalculateAge(DateTime dob)
        {
            // Save today's date.
            var today = DateTime.Today;
            // Calculate the age.
            var age = today.Year - dob.Year;
            // To the year,the user was born in case of a leap year
            if (dob.Date > today.AddYears(-age))
            {
                age--;
            }
            return age;            
        }
        #endregion

        #region GenerateCreditCard
        /// <summary>
        /// To Generate the Credit Card Type
        /// </summary>
        /// <param name="age"></param>
        /// <param name="objUserInfoModel"></param>
        /// <returns></returns>
        public void GenerateCreditCard(int age, Model.UserInfo objUserInfoModel)
        {
            // Checking if Age is less than 18
            if (age < 18)
            {
                objUserInfoModel.ResultStatus = Result.NoCard.ToString();
                objUserInfoModel.ImageSource = Result.NoCardImage.ToString();
                objUserInfoModel.CardContent = Result.NoCardContent.ToString();
            }
            else
            // Checking if Annual Income is greater than £30,000
            if (Convert.ToInt64(objUserInfoModel.AnnualIncome) > 30000)
            {
                objUserInfoModel.ResultStatus = Result.BarclayCard.ToString();
                objUserInfoModel.ImageSource = Result.BarclayCardImage.ToString();
                objUserInfoModel.CardContent = Result.BarclayCardContent.ToString();
            }
            else
            {
                objUserInfoModel.ResultStatus = Result.VanquisCard.ToString();
                objUserInfoModel.ImageSource = Result.VanquisCardImage.ToString();
                objUserInfoModel.CardContent = Result.VanquisCardContent.ToString();
            }

        }
        #endregion

        #region Adding User Information and Result Status
        /// <summary>
        /// Adding User info for credit card pre qualification.
        /// </summary>
        /// <param name="objUserInfoModel"></param>
        /// <returns></returns>
        public bool AddUser(Model.UserInfo objUserInfoModel)
        {
            //To calculate the age of User
            int age = CalculateAge(objUserInfoModel.DateOfBirth);

            //To Generate the Credit Card Type
            GenerateCreditCard(age,objUserInfoModel);


            Data.UserInfo objUserInfo = new Data.UserInfo()
            {
                FirstName = objUserInfoModel.FirstName,
                LastName = objUserInfoModel.LastName,
                DateOfBirth = Convert.ToDateTime(objUserInfoModel.DateOfBirth),
                AnnualIncome = objUserInfoModel.AnnualIncome,
                ResultStatus = objUserInfoModel.ResultStatus 
            };

            objCreditCardToolEntity.UserInfoes.Add(objUserInfo);
            objCreditCardToolEntity.SaveChanges();//Saving Data
            return true;           
        }
        #endregion
    }
}
