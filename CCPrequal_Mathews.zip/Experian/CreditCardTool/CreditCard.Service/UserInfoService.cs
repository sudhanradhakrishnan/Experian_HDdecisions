﻿using CreditCard.BL;
using CreditCard.Model;

namespace CreditCard.Service
{
    public class UserInfoService
    {
        private IUserInfoBL _iUserInfoBL;
        public UserInfoService(IUserInfoBL iUserInfoBL)
        {
            _iUserInfoBL = iUserInfoBL;
        }

        /// <summary>
        ///  Adding User info for credit card pre qualification.
        /// </summary>
        /// <param name="objUserInfoModel"></param>
        /// <returns></returns>
        public bool AddUser(UserInfo objUserInfoModel)
        {
            return _iUserInfoBL.AddUser(objUserInfoModel);
        }

    }
}
