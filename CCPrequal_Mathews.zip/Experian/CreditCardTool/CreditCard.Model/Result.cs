﻿using System;
using System.Runtime.Serialization;

namespace CreditCard.Model
{
    public class Result
    {
        // No Credit Card Contents
        public const string NoCard = "No credit cards are available.";
        public const string NoCardImage = "~/Content/no-credit-card.jpg";
        public const string NoCardContent = "";

        // Barclay Credit Card Contents
        public const string BarclayCard = "BarclayCard Credit Card Approved.";
        public const string BarclayCardImage = "~/Content/Barclay.jpg";
        public const string BarclayCardContent = "The card offers a 0% intro APR of 15 billing cycles for both purchases and balance transfers made in the first 60 days (15.49% – 25.49% variable APR thereafter).";

        // Vanquis Credit Card Contents
        public const string VanquisCard = "Vanquis Credit Card Approved.";
        public const string VanquisCardImage = "~/Content/Vanquis.jpg";
        public const string VanquisCardContent = "The card offers a 0% intro APR of 10 billing cycles for both purchases and balance transfers made in the first 60 days (20.59% – 25.49% variable APR thereafter).";

    }
}
