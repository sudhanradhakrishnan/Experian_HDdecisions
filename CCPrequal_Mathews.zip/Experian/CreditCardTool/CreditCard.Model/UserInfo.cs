﻿using CreditCard.Model.CustomValidation;
using System;
using System.ComponentModel.DataAnnotations;

namespace CreditCard.Model
{
    public class UserInfo
    {
        // First Name 
        [Display(Name = "First Name")]
        [Required(ErrorMessage = "Please enter the First Name")]
        [StringLength(50, ErrorMessage = "First Name is too long,Please enter a valid First Name")]
        [RegularExpression(@"^([a-zA-Z0-9 \.\&\'\-]+)$", ErrorMessage = "Enter only alphabets or numbers for First Name")]
        public string FirstName { get; set; }

        // Last Name 
        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "Please enter the Last Name")]
        [RegularExpression(@"^([a-zA-Z0-9 \.\&\'\-]+)$", ErrorMessage = "Enter only alphabets or numbers for Last Name")]
        public string LastName { get; set; }

        // Date of Birth 
        [Display(Name = "Date Of Birth")]
        [Required(ErrorMessage = "Please enter the Date Of Birth")]
        [CustomDate(ErrorMessage = "Date of Birth should not be a future date")] //To check whether the date of birth is a future date or not
        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }

        // Annual Income(£)
        [Display(Name = "Annual Income(£)")]
        [Required(ErrorMessage = "Please enter the Annual Income")]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Please enter valid income")]
        [StringLength(19, ErrorMessage = "Please enter a valid income")]
        public string AnnualIncome { get; set; }

        // Result Status
        public string ResultStatus { get; set; }

        // Image Source
        public string ImageSource { get; set; }

        // Card Content
        public string CardContent { get; set; }
    }
}
