/****** Object:  Table [dbo].[UserInfo]    Script Date: 7/26/2020 9:39:28 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserInfo]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[UserInfo](
	[UserID] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](50) NOT NULL,
	[LastName] [varchar](max) NOT NULL,
	[DateOfBirth] [datetime] NOT NULL,
	[AnnualIncome] [varchar](50) NOT NULL,
	[ResultStatus] [varchar](max) NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[UserID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

ALTER TABLE [dbo].[UserInfo] ADD  CONSTRAINT [DF_UserInfo_CreatedDate]  DEFAULT (getdate()) FOR [CreatedDate]
GO

/****** Object:  StoredProcedure [dbo].[SP_UserInfo]    Script Date: 7/31/2020 1:21:10 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_UserInfo] 
AS
BEGIN

      SELECT [FirstName] AS [First Name] --First Name
      ,[LastName] AS [Last Name] --Last Name
      ,FORMAT ([DateOfBirth], 'MM/dd/yyyy') AS [Date Of Birth(MM/DD/YYYY)] --Date of Birth in MM/DD/YYYY format 
      ,[AnnualIncome] AS [Annual Income(£)] --Annual Income
      ,[ResultStatus] AS [Status] --Status
	  ,FORMAT ([CreatedDate], 'MM/dd/yyyy') AS [Created Date(MM/DD/YYYY)] --Created Date
	FROM [dbo].[UserInfo]

END
GO