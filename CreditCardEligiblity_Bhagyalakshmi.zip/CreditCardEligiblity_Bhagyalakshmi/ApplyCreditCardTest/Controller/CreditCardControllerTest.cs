﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Web.Mvc;
using Moq;
using CreditCardPreQalification.DataLayer.Model;
using CreditCardPreQalification.ServiceLayer.UserRegistration;
using CreditCardPreQalification.DataLayer.JsonOperations;
using CreditCardPreQalification.Web.Controllers;

namespace ApplyCreditCardTest.Controller
{
    [TestClass]
    public class CreditCardControllerTest
    {
        [TestMethod]
        public void CreditCardRegistrationPageisDisplayingOnclickingNavLink()
        {
            // arrange
            var controller = SetupControllerMock();

            // act
            var result = controller.CreditCardRegistration() as ViewResult;

            // assert
            Assert.AreEqual("CreditCardRegistration", result.ViewName);

        }


        //[TestMethod]
        //public void RedirectingToResultPageAfterSuccessfullRegistration()
        //{
        //    // arrange
        //    var controller = SetupControllerMock();

        //    // act
        //    UserEligibleCreditCardDetails userEligibleCreditCardDetails = new UserEligibleCreditCardDetails();
        //    userEligibleCreditCardDetails.EligibleCreditCard = "Barclaycard";
        //    var result = (System.Web.Mvc.RedirectToRouteResult)controller.CreditCardRegistration(GetRegistrationDetails());
          
        //    // assert            
        //    Assert.AreEqual("CreditCardResult", result.RouteValues["action"]);            
        //}

        [TestMethod]
        public void ResultPageIsDisplayedAfterSuccessfullRegistrationBasedOnEligibilty()
        {
            // arrange
            var controller = SetupControllerMock(); 
         
            // act
            var result = controller.CreditCardResult(GeteligibleCard()) as ViewResult;          
            var creditCardDetails = (CreditCardDetails)result.ViewData.Model;
                                 
            // assert          
            Assert.AreEqual("CreditCardResult", result.ViewName);            
        }

              

        private CreditCardController SetupControllerMock()
        {
            CreditCardDetails getCreditCardDetails = GetCreditCardDetails();
            
            Mock<ICreditCardRegistration> userRegistration = new Mock<ICreditCardRegistration>();            
            userRegistration.Setup(e => e.UserRegistration(GetRegistrationDetails())).Returns(GetUserEligibleCreditCardDetails());

            Mock<IEligibleCreditCardDetails> jsonOperations = new Mock<IEligibleCreditCardDetails>();
            jsonOperations.Setup(e => e.GetCardDetails(GeteligibleCard())).Returns(getCreditCardDetails);
            
            var controller = new CreditCardController(userRegistration.Object, jsonOperations.Object);

            return controller;
        }

        private string GeteligibleCard()
        {
            return "Barclaycard";
        }

        private CreditCardRegistrationDeatils GetRegistrationDetails()
        {
            var userDeatils = new CreditCardRegistrationDeatils
            {
                FirstName = "Jack",
                LastName = "Tom",
                DateOfBirth = DateTime.ParseExact("20-Oct-2000", "dd-MMM-yyyy", null),
                AnnualIncome = "50000"
            };

            return userDeatils;
        }

        private UserEligibleCreditCardDetails GetUserEligibleCreditCardDetails()
        {
            var cardDeatils = new UserEligibleCreditCardDetails
            {
                FirstName = "Jack",
                LastName = "Tom",
                EligibleCreditCard = "Barclaycard"

            };

            return cardDeatils;
        }

        

        private CreditCardDetails GetCreditCardDetails()
        {
            var creditCardDetails = new CreditCardDetails
            {
                CardName = "Barclaycard",
                Message = "Congratulations!! You are successfully registered for Barclaycard CreditCard.",
                Image = "barclay.jfif",
                APR = "The ongoing APR is 13.99 % -26.99 % Variable APR.A safer choice might be a card with a true 0 % introductory APR period, during which no interest accumulates on purchases at all.",
                PromotionalMessage = "Barclaycard is a high interest creditwith 0.25 % cashback on your everyday spend*.No fees abroad, you'll be able to withdraw cash from an ATM or buy your souvenirs without any charges and benefit from Visa's competitive exchange rate."
            };

            return creditCardDetails;
        }

    }
}
