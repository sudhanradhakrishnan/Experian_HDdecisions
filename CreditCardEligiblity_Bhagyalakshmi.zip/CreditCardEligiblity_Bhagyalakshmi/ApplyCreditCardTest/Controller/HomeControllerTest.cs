﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.Mvc;
using CreditCardPreQalification.Web.Controllers;

namespace ApplyCreditCardTest.Controller
{
    [TestClass]
    public class HomeControllerTest
    {
        [TestMethod]
        public void HomePageisDisplayingOnclickingNavLink()
        {
            // arrange
            var controller = new HomeController();

             // act
            var result = controller.Index() as ViewResult;

            // assert
            Assert.AreEqual("Index", result.ViewName);

        }
    }
    
}
