﻿using CreditCardPreQalification.BussinessLogicLayer.CreditCardEligibility;
using CreditCardPreQalification.DataLayer.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace CreditCardPreQalification.UnitTest.BussinessLogicLayer
{

    [TestClass]
    public class CreditCardControllerTest
    {
        [TestMethod]
        public void CheckEligibilityOfAUsersBasedOnHisageandIncome()
        {

            // arrange
            UserEligibleCreditCardDetails userEligibleCreditCardDetails;
            CreditCardEligibility creditCardEligibility = new CreditCardEligibility();

            // act
            CreditCardRegistrationDeatils registrationDetails = GetRegistrationDetails();
            userEligibleCreditCardDetails = creditCardEligibility.GetEligibleCreditCard(registrationDetails);
            
            // assert          
            Assert.AreEqual("Barclaycard", userEligibleCreditCardDetails.EligibleCreditCard);


            // arrange
            registrationDetails.AnnualIncome = "20000";

            // act
            userEligibleCreditCardDetails = creditCardEligibility.GetEligibleCreditCard(registrationDetails);

            // assert          
            Assert.AreEqual("Vanquis", userEligibleCreditCardDetails.EligibleCreditCard);


            // arrange
            registrationDetails.DateOfBirth = DateTime.ParseExact("20-Oct-2008", "dd-MMM-yyyy", null);

            // act
            userEligibleCreditCardDetails = creditCardEligibility.GetEligibleCreditCard(registrationDetails);

            // assert          
            Assert.AreEqual("NoEligibleCards", userEligibleCreditCardDetails.EligibleCreditCard);

        }

        [TestMethod]
        public void SetEligibileUserCardDetailsofAUsersBasedOnHisageandIncome()
        {
            // arrange
            UserEligibleCreditCardDetails userEligibleCreditCardDetails;
            CreditCardEligibility creditCardEligibility = new CreditCardEligibility();

            // act
            CreditCardRegistrationDeatils registrationDetails = GetRegistrationDetails();
            userEligibleCreditCardDetails = creditCardEligibility.SetEligibileUserCardDetails(registrationDetails, "Barclaycard");

            // assert          
            Assert.AreEqual("John", userEligibleCreditCardDetails.FirstName);
            Assert.AreEqual("Sam", userEligibleCreditCardDetails.LastName);
        }

        private CreditCardRegistrationDeatils GetRegistrationDetails()
        {
            var userDeatils = new CreditCardRegistrationDeatils
            {
                FirstName = "John",
                LastName = "Sam",
                DateOfBirth = DateTime.ParseExact("20-Oct-1990", "dd-MMM-yyyy", null),
                AnnualIncome = "50000"                
            };

            return userDeatils;
        }

    }
}
