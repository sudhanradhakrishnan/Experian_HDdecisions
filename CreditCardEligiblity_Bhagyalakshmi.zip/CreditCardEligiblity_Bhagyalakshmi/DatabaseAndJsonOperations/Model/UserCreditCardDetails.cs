﻿namespace CreditCardPreQalification.DataLayer.Model
{
    public class UserEligibleCreditCardDetails
    {
        public string UserID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EligibleCreditCard { get; set; }
      
    }
}