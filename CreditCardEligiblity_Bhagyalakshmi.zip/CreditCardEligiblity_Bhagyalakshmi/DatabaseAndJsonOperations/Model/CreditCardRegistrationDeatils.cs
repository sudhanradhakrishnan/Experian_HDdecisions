﻿using CreditCardPreQalification.DataLayer.DatabaseOperations;
using System;
using System.ComponentModel.DataAnnotations;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace CreditCardPreQalification.DataLayer.Model
{
    public class CreditCardRegistrationDeatils
    {
        //User Registration properties
        [BsonId]
        public ObjectId Id { get; set; } 

        [Required(ErrorMessage = "Please Enter First Name")]
        [StringLength(20, MinimumLength = 1)]
        [RegularExpression(@"^[a-zA-Z0-9_]*[a-zA-Z][a-zA-Z0-9_]*$",
        ErrorMessage = "Enter a valid First Name")]
        
        public string FirstName { get; set; }


        [Required(ErrorMessage = "Please Enter Last Name")]
        [StringLength(20, MinimumLength = 1)]
        [RegularExpression(@"^[a-zA-Z0-9_]*[a-zA-Z][a-zA-Z0-9_]*$",
        ErrorMessage = "Enter a valid Last Name")]
        public string LastName { get; set;}


        [Required]
        [DataType(DataType.Date)]
        [CustomAgeValidator]
        public DateTime? DateOfBirth { get; set; }


        [StringLength(10, MinimumLength = 1)]
        [Required(ErrorMessage = "Please Enter Annual Income")]        
        [RegularExpression(@"^\$?([0-9]{1,3},([0-9]{3},)*[0-9]{3}|[0-9]+)(\.[0-9][0-9])?$",
        ErrorMessage = "Enter a valid AnnualIncome")]
        public string AnnualIncome { get; set; }

    }
}