﻿namespace CreditCardPreQalification.DataLayer.Model
{
    public class CreditCardDetails
    {
        public string CardName { get; set; }
        public string Message { get; set; }
        public string Image { get; set; }
        public string APR { get; set; }
        public string PromotionalMessage { get; set; }
    }
}