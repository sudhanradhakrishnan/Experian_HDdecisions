﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CreditCardPreQalification.DataLayer.DatabaseOperations
{
    public class CustomAgeValidator : ValidationAttribute
    {
        // Custom validation for future dates and past 2 year's dates for DOB
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                DateTime date;

                return DateTime.TryParse(value.ToString(), out date)
                    ? (date.AddYears(2) < DateTime.Now ? ValidationResult.Success : new ValidationResult("Please Enter a Valid Date of birth."))
                    : new ValidationResult("Please Enter a Valid Date of birth.");
            }
            else
            {
                return new ValidationResult("" + validationContext.DisplayName + " is required");
            }
        }
    }
 }