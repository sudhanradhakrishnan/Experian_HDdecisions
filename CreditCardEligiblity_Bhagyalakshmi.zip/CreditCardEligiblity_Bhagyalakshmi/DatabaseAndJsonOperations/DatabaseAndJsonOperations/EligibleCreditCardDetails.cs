﻿using CreditCardPreQalification.DataLayer.Model;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CreditCardPreQalification.DataLayer.JsonOperations
{
    public class EligibleCreditCardDetails : IEligibleCreditCardDetails
    {
        public CreditCardDetails GetCardDetails(string eligibleCreditCard)
        {
            // Getting eligible credit card details by deserialize JSON file 
            CreditCardDetails creditCard = new CreditCardDetails();
            string file = null;
            if (HttpContext.Current != null)
            {
                file = HttpContext.Current.Server.MapPath("~/Content/json/CreditCardDetails.json");

                string Json = System.IO.File.ReadAllText(file);
                var temp = Newtonsoft.Json.JsonConvert.DeserializeObject<List<CreditCardDetails>>(Json);

                temp.ToList().ForEach(m =>
                {
                    if (m.CardName == eligibleCreditCard)
                        creditCard = m;
                    return;
                });
            }
            return creditCard;
        }
    }
}