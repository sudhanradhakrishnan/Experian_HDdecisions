﻿using CreditCardPreQalification.DataLayer.Model;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Builders;
using System;

namespace CreditCardPreQalification.DataLayer.DatabaseOperations
{
    public class UserRegistrationDetails : IUserRegistrationDetails
    {
        public void InsertUserRegisteretails(CreditCardRegistrationDeatils registrationDetails)
        {
            // Insert user registration details to mongodb
            try
            {
                var connection = "mongodb://localhost";
                var client = new MongoClient(connection);
                var database = client.GetDatabase("CreditCard");
                var collection = database.GetCollection<CreditCardRegistrationDeatils>("CreditCardUserRegistrationDetails");
                                
                collection.InsertOneAsync(registrationDetails);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertUserEligibleCreditCardDetails(UserEligibleCreditCardDetails userEligibleCreditCardDetails)
        {
            // Insert user eligible card deatils to mongodb
            try
            {
                var connection = "mongodb://localhost";
                var client = new MongoClient(connection);
                var database = client.GetDatabase("CreditCard");
                var collection = database.GetCollection<UserEligibleCreditCardDetails>("UserEligibleCreditCardDetails");

                collection.InsertOneAsync(userEligibleCreditCardDetails);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}