﻿using CreditCardPreQalification.DataLayer.Model;

namespace CreditCardPreQalification.DataLayer.DatabaseOperations
{
    public interface IUserRegistrationDetails
    {
        void InsertUserRegisteretails(CreditCardRegistrationDeatils registrationDetails);
        void InsertUserEligibleCreditCardDetails(UserEligibleCreditCardDetails userEligibleCreditCardDetails);
    }
}
