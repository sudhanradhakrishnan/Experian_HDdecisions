﻿using CreditCardPreQalification.DataLayer.Model;

namespace CreditCardPreQalification.DataLayer.JsonOperations
{
    public interface IEligibleCreditCardDetails
    {
        CreditCardDetails GetCardDetails(string eligibleCreditCard);
    }
}
