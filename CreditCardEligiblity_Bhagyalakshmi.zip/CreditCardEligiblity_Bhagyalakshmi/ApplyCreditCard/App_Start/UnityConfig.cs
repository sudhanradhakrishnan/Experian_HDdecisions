using CreditCardPreQalification.BussinessLogicLayer.CreditCardEligibility;
using CreditCardPreQalification.DataLayer.DatabaseOperations;
using CreditCardPreQalification.DataLayer.JsonOperations;
using CreditCardPreQalification.ServiceLayer.UserRegistration;
using System.Web.Mvc;
using Unity;
using Unity.Mvc5;

namespace ApplyCreditCard
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();          
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
            container.RegisterType<ICreditCardEligibility, CreditCardEligibility>();
            container.RegisterType<IUserRegistrationDetails, UserRegistrationDetails>();
            container.RegisterType<ICreditCardRegistration, CreditCardRegistration>();
            container.RegisterType<IEligibleCreditCardDetails, EligibleCreditCardDetails>();          
        }
    }
}