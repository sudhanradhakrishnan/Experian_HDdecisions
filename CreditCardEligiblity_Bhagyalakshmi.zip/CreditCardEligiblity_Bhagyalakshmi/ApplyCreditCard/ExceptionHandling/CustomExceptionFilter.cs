﻿using System;
using System.Web.Mvc;

namespace CreditCardPreQalification.Web.ExceptionHandling
{
    public class CustomExceptionFilter : FilterAttribute, IExceptionFilter

    {
        public void OnException(ExceptionContext filterContext)
        {
            if (!filterContext.ExceptionHandled && filterContext.Exception is NullReferenceException)
            {            
                filterContext.Result = new ViewResult()
                {
                    ViewName = "Error"
                };
                filterContext.ExceptionHandled = true;
            }
        }
    }

}