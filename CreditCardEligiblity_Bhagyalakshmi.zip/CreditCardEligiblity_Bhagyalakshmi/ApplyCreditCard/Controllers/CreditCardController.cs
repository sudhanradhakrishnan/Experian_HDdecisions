﻿using System.Web.Mvc;
using CreditCardPreQalification.Web.ExceptionHandling;
using CreditCardPreQalification.ServiceLayer.UserRegistration;
using CreditCardPreQalification.DataLayer.JsonOperations;
using CreditCardPreQalification.DataLayer.Model;

namespace CreditCardPreQalification.Web.Controllers
{
    
    [CustomExceptionFilter]
    public class CreditCardController : Controller
    {

        private readonly ICreditCardRegistration RegistrationCreditCard;
        private readonly IEligibleCreditCardDetails EligibleCreditCardDetails;
      
        public CreditCardController(ICreditCardRegistration registrationCreditCard, IEligibleCreditCardDetails eligibleCreditCardDetails)
        {
            // Dependency injection from RegistrationCreditCard and jsonOperations with unity
            RegistrationCreditCard = registrationCreditCard;
            EligibleCreditCardDetails = eligibleCreditCardDetails;
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult CreditCardRegistration()
        {           
            return View("CreditCardRegistration");
        }

        [CustomExceptionFilter]
        [HttpPost]
        public ActionResult CreditCardRegistration(CreditCardRegistrationDeatils registrationDetails)
        {
            if (ModelState.IsValid)
            {
                UserEligibleCreditCardDetails userEligibleCreditCardDetails = RegistrationCreditCard.UserRegistration(registrationDetails);               
                return RedirectToAction("CreditCardResult", new { eligibleCreditCard = userEligibleCreditCardDetails.EligibleCreditCard });
            }
            return View();
        }

        [CustomExceptionFilter]
        public ActionResult CreditCardResult(string eligibleCreditCard)
        {
            return View("CreditCardResult", EligibleCreditCardDetails.GetCardDetails(eligibleCreditCard));
        }

    }
}