﻿using CreditCardPreQalification.DataLayer.Model;

namespace CreditCardPreQalification.ServiceLayer.UserRegistration
{
    public interface ICreditCardRegistration
    {
        UserEligibleCreditCardDetails UserRegistration(CreditCardRegistrationDeatils registrationDetails);       

    }
}