﻿using CreditCardPreQalification.BussinessLogicLayer.CreditCardEligibility;
using CreditCardPreQalification.DataLayer.DatabaseOperations;
using CreditCardPreQalification.DataLayer.Model;


namespace CreditCardPreQalification.ServiceLayer.UserRegistration
{
    public class CreditCardRegistration : ICreditCardRegistration
    {
        // Service layer connects web/UI to bussiness logic
        private readonly ICreditCardEligibility CreditCardEligibility;
        private readonly IUserRegistrationDetails UserRegistrationDetails;

        public CreditCardRegistration(ICreditCardEligibility creditCardEligiblity, IUserRegistrationDetails userRegistrationDetails)
        {
            // Dependency injection from CreditCardEligiblityCheck and  DatabaseOperations with unity
            CreditCardEligibility = creditCardEligiblity;
            UserRegistrationDetails = userRegistrationDetails;
        }

        public UserEligibleCreditCardDetails UserRegistration(CreditCardRegistrationDeatils registrationDetails)
        {
            // Register a user, based on his eligibility, and the save the details to batabase            
            UserRegistrationDetails.InsertUserRegisteretails(registrationDetails);
            UserEligibleCreditCardDetails userEligibleCreditCardDetails = CreditCardEligibility.GetEligibleCreditCard(registrationDetails);
            UserRegistrationDetails.InsertUserEligibleCreditCardDetails(userEligibleCreditCardDetails);

            return userEligibleCreditCardDetails;
        }

    }
}
