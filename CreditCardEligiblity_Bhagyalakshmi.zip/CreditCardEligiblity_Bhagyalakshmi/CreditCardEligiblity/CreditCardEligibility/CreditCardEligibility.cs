﻿using System;
using CreditCardPreQalification.BussinessLogicLayer.Model;
using CreditCardPreQalification.DataLayer.Model;

namespace CreditCardPreQalification.BussinessLogicLayer.CreditCardEligibility
{
    public class CreditCardEligibility : ICreditCardEligibility
    {
        // CreditCard eligibility check
        public UserEligibleCreditCardDetails GetEligibleCreditCard(CreditCardRegistrationDeatils registrationDetails)
        {
            try
            {
                // check eligibility of a user based on his/her age and income
                int age = GetAgeFromDob((DateTime)registrationDetails.DateOfBirth);

                var eligibleCreditCard = (age >= 18) ? ((Double.Parse(registrationDetails.AnnualIncome) >= 30000 ?
                EligibleCreditCards.Barclaycard : EligibleCreditCards.Vanquis)) : EligibleCreditCards.NoEligibleCards;

                return SetEligibileUserCardDetails(registrationDetails, eligibleCreditCard);               

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int GetAgeFromDob(DateTime dateOfBirth)
        {
            try
            {
                // calculate age from Dob
                int now = int.Parse(DateTime.Now.ToString("yyyyMMdd"));
                int dob = int.Parse(dateOfBirth.ToString("yyyyMMdd"));
                int age = (now - dob) / 10000;
                return age;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public UserEligibleCreditCardDetails SetEligibileUserCardDetails(CreditCardRegistrationDeatils registrationDetails, string eligibleCreditCard)
        {
            try
            {
                UserEligibleCreditCardDetails userEligibleCreditCardDetails = new UserEligibleCreditCardDetails
                {
                    UserID = (registrationDetails.Id).ToString(),
                    FirstName = registrationDetails.FirstName,
                    LastName = registrationDetails.LastName,
                    EligibleCreditCard = eligibleCreditCard
                };

                return userEligibleCreditCardDetails;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }

}
