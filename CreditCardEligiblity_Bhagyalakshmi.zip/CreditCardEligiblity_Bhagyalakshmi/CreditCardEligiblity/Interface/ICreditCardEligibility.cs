﻿using CreditCardPreQalification.DataLayer.Model;
using System;

namespace CreditCardPreQalification.BussinessLogicLayer.CreditCardEligibility
{
    public interface ICreditCardEligibility
    {
        UserEligibleCreditCardDetails GetEligibleCreditCard(CreditCardRegistrationDeatils registrationDetails);
        int GetAgeFromDob(DateTime dateOfBirth);
        UserEligibleCreditCardDetails SetEligibileUserCardDetails(CreditCardRegistrationDeatils registrationDetails, string eligibleCreditCard);
    }
}
