﻿namespace CreditCardPreQalification.BussinessLogicLayer.Model
{ 
    static class EligibleCreditCards
    {
        public const string NoEligibleCards = "NoEligibleCards";
        public const string Vanquis = "Vanquis";
        public const string Barclaycard = "Barclaycard";
    }
}