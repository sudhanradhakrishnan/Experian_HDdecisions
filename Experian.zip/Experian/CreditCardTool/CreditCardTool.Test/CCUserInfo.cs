﻿using System;
using CreditCard.BL;
using CreditCard.Model;
using CreditCard.Service;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace CreditCardTool.Test
{
    [TestClass]
    public class CCUserInfo
    {
        [TestMethod]
        public void Test_AddUser()
        {
            //Arrange  
            var user = new UserInfo()
            {
                FirstName = "John" ,
                LastName="Miller",
                DateOfBirth=Convert.ToDateTime("11/23/1985"),
                AnnualIncome="30000"
            };

            //Creating Moq user service
            UserInfoBL obj = new UserInfoBL();
            var mockRepo = new Mock<IUserInfoBL>();
            mockRepo.Setup(x => x.AddUser(user)).Returns(true);

            //Checking whether Assert value are equal           
            var objectAdd = new UserInfoService(mockRepo.Object);
            var data = objectAdd.AddUser(user);
            Assert.AreEqual(data, true);
        }

        [TestMethod]
        public void Test_UserAge()
        {
            //Arrange  
            var user = new UserInfo()
            {
                FirstName = "Steve",
                LastName = "John",
                DateOfBirth = Convert.ToDateTime("11/23/2019"),
                AnnualIncome = "30000"
            };

            //Creating Moq user service
            UserInfoBL obj = new UserInfoBL();
            var mockRepo = new Mock<IUserInfoBL>();
            mockRepo.Setup(x => x.AddUser(user)).Returns(true);

            //Checking whether Assert value are equal           
            var objectAdd = new UserInfoService(mockRepo.Object);
            var data = objectAdd.AddUser(user);
            Assert.AreEqual(data, true);
        }

        [TestMethod]
        public void Test_UserAnnualIncomeHigh()
        {
            //Arrange  
            var user = new UserInfo()
            {
                FirstName = "Han",
                LastName = "Sam",
                DateOfBirth = Convert.ToDateTime("11/23/1985"),
                AnnualIncome = "50000"
            };

            //Creating Moq user service
            UserInfoBL obj = new UserInfoBL();
            var mockRepo = new Mock<IUserInfoBL>();
            mockRepo.Setup(x => x.AddUser(user)).Returns(true);

            //Checking whether Assert value are equal           
            var objectAdd = new UserInfoService(mockRepo.Object);
            var data = objectAdd.AddUser(user);
            Assert.AreEqual(data, true);
        }

        [TestMethod]
        public void Test_UserAnnualIncomeLow()
        {
            //Arrange  
            var user = new UserInfo()
            {
                FirstName = "Matt",
                LastName = "Rob",
                DateOfBirth = Convert.ToDateTime("11/23/1985"),
                AnnualIncome = "20000"
            };

            //Creating Moq user service
            UserInfoBL obj = new UserInfoBL();
            var mockRepo = new Mock<IUserInfoBL>();
            mockRepo.Setup(x => x.AddUser(user)).Returns(true);

            //Checking whether Assert value are equal           
            var objectAdd = new UserInfoService(mockRepo.Object);
            var data = objectAdd.AddUser(user);
            Assert.AreEqual(data, true);
        }
    }
}
