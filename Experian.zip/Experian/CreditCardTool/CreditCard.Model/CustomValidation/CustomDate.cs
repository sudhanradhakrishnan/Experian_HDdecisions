﻿using System;
using System.ComponentModel.DataAnnotations;

namespace CreditCard.Model.CustomValidation
{
    public class CustomDate : ValidationAttribute
    {       
        /// <summary>
        /// Validate Date of Birth which should not be a future date
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public override bool IsValid(object value)
        {
            DateTime dateTime = Convert.ToDateTime(value);
            return dateTime <= DateTime.Now;
        }
    }
}
